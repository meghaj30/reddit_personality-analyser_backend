package com.example.redditpersonalityanalyser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedditPersonalityAnalyserApplication {
    public static void main(String[] args) {
        SpringApplication.run(RedditPersonalityAnalyserApplication.class, args);
    }
}