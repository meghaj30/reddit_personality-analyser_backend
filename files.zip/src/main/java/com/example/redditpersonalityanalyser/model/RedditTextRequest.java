package com.example.redditpersonalityanalyser.model;

public class RedditTextRequest {
    private String text;

    public RedditTextRequest() {}

    public RedditTextRequest(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}