package com.example.redditpersonalityanalyser.model;

import java.util.Map;

public class PersonalityResult {
    private Map<String, Double> traits;

    public PersonalityResult() {}

    public PersonalityResult(Map<String, Double> traits) {
        this.traits = traits;
    }

    public Map<String, Double> getTraits() {
        return traits;
    }

    public void setTraits(Map<String, Double> traits) {
        this.traits = traits;
    }
}